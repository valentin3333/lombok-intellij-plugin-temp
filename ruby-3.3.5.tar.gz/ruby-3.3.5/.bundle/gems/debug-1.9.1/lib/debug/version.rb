# frozen_string_literal: true

module DEBUGGER__
  VERSION = "1.9.1"
end
