#include <stdio.h>

void a()
{
    printf ("In function a\n");
}
