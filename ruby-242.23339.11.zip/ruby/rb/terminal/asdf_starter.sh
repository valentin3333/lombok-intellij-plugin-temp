asdf_bin_root=$(dirname $RUBY_VERSION_MANAGER_PATH)
source "${asdf_bin_root}/../asdf.sh"
asdf shell ruby $RUBY_VERSION_MANAGER_DISTRIBUTION_ID
