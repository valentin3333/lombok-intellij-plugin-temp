require 'bundler/setup'
require 'rails/railtie'

module RubyMine
  class Railtie < Rails::Railtie
    initializer :rm_consoles_config do
      require_relative 'irb_config'
      begin
        require_relative 'pry_config'
      rescue LoadError => _
      end
    end
  end
end