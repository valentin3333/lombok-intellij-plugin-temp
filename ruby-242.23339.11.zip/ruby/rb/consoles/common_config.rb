# This `require` guarantees that config scripts are run with the same load paths as the executable when `bundle exec` is used.
require 'bundler/setup' if (ENV['RUBYOPT'] || '').include?('bundler/setup')

# See RUBY-32600, and RUBY-29509; this workaround is technically not necessary when `TERM=dumb` is set, however we cannot guarantee that all
# users have received the updated IRB configuration template (as they may have modified the template themselves). This workaround is
# included temporarily for those users, and it is likely safe to remove in a couple of releases.
begin
  require 'reline'

  class Reline::Core
    def ambiguous_width
      1
    end

    private def may_req_ambiguous_char_width; end
  end
rescue LoadError => _
end
