# frozen_string_literal: true

# EncodingError is the base class for encoding errors.
class EncodingError < StandardError
end
