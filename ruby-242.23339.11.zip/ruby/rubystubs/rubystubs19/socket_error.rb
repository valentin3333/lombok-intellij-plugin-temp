# frozen_string_literal: true

# SocketError is the error class for socket.
class SocketError < StandardError
end
