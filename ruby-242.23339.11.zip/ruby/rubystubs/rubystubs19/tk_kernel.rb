# frozen_string_literal: true

class TkKernel
  def initialize(*args) end
end
