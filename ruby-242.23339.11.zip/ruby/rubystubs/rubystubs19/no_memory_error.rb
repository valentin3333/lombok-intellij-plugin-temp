# frozen_string_literal: true

# Raised when memory allocation fails.
class NoMemoryError < Exception
end
