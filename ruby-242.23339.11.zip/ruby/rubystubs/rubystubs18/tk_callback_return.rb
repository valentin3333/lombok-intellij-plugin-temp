# frozen_string_literal: true

# ---------------------------------------------------------------
class TkCallbackReturn < StandardError
end
