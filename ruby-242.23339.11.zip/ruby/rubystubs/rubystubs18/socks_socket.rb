# frozen_string_literal: true

class SOCKSSocket < TCPSocket
  def initialize(p1, p2) end

  def close; end
end
