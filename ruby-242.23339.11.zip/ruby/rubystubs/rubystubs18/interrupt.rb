# frozen_string_literal: true

class Interrupt < SignalException
  def initialize(p1 = v1) end
end
