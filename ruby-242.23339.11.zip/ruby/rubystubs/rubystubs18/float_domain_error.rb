# frozen_string_literal: true

class FloatDomainError < RangeError
end
