# frozen_string_literal: true

class LoadError < ScriptError
end
