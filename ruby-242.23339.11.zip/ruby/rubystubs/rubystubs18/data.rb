# frozen_string_literal: true

class Data
end
