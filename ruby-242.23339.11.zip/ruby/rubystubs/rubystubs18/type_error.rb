# frozen_string_literal: true

class TypeError < StandardError
end
