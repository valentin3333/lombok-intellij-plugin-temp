# frozen_string_literal: true

class WIN32OLERuntimeError < RuntimeError
end
