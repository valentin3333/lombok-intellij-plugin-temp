# frozen_string_literal: true

class RegexpError < StandardError
end
