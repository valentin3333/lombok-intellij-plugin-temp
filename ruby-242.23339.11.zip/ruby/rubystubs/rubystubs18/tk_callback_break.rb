# frozen_string_literal: true

class TkCallbackBreak < StandardError
end
