# frozen_string_literal: true

class TkCallbackEntry < TkKernel
  # /
  def self.inspect; end
end
