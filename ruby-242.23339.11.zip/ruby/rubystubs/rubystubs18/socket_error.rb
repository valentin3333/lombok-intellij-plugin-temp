# frozen_string_literal: true

class SocketError < StandardError
end
