# frozen_string_literal: true

module Constants
  APPEND = _
  BINARY = _
  CREAT = _
  EXCL = _
  FNM_CASEFOLD = _
  FNM_DOTMATCH = _
  FNM_NOESCAPE = _
  FNM_PATHNAME = _
  FNM_SYSCASE = _
  LOCK_EX = _
  LOCK_NB = _
  LOCK_SH = _
  LOCK_UN = _
  NOCTTY = _
  NONBLOCK = _
  RDONLY = _
  RDWR = _
  SYNC = _
  TRUNC = _
  WRONLY = _
end
