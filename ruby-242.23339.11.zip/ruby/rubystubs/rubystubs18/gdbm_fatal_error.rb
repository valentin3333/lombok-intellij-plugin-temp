# frozen_string_literal: true

class GDBMFatalError < Exception
end
