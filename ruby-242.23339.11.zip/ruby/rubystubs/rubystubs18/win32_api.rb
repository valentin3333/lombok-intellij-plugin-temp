# frozen_string_literal: true

class Win32API
  def initialize(p1, p2, p3, p4) end

  def call(*args) end
  alias Call call
end
