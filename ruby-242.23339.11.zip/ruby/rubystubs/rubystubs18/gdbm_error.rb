# frozen_string_literal: true

class GDBMError < StandardError
end
