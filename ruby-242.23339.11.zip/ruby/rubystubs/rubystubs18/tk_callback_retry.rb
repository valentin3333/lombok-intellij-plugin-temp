# frozen_string_literal: true

class TkCallbackRetry < TkLocalJumpError
end
