# frozen_string_literal: true

class DBMError < StandardError
end
