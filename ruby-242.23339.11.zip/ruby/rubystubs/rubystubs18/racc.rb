# frozen_string_literal: true

module Racc
  class CparseParams
  end

  class Parser
    Racc_Runtime_Core_Id_C = _
    Racc_Runtime_Core_Version_C = _

    private

    def _racc_do_parse_c(p1, p2) end

    def _racc_yyparse_c(p1, p2, p3, p4) end
  end
end
