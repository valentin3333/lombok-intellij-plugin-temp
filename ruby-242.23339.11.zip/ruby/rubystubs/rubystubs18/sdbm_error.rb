# frozen_string_literal: true

class SDBMError < StandardError
end
