# frozen_string_literal: true

class IndexError < StandardError
end
