# frozen_string_literal: true

class Tms
end
