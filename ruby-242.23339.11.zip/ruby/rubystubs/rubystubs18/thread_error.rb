# frozen_string_literal: true

class ThreadError < StandardError
end
