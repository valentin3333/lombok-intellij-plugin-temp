# frozen_string_literal: true

class IOError < StandardError
end
