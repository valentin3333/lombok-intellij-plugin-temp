# frozen_string_literal: true

class StopIteration < IndexError
end
