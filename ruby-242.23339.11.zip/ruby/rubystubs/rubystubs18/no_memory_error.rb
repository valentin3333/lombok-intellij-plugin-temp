# frozen_string_literal: true

class NoMemoryError < Exception
end
