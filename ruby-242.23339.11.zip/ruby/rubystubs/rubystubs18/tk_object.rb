# frozen_string_literal: true

class TkObject < TkKernel
  # /
  def path; end
end
