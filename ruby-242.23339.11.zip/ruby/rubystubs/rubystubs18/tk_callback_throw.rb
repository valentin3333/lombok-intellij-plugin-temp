# frozen_string_literal: true

class TkCallbackThrow < TkLocalJumpError
end
