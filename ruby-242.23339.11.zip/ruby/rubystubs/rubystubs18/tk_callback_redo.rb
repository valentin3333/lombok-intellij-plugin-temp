# frozen_string_literal: true

class TkCallbackRedo < TkLocalJumpError
end
