# frozen_string_literal: true

class SystemStackError < StandardError
end
