# frozen_string_literal: true

class TkLocalJumpError < eLocalJumpError
end
