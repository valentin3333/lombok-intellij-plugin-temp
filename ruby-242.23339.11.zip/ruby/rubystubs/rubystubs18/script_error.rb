# frozen_string_literal: true

class ScriptError < Exception
end
