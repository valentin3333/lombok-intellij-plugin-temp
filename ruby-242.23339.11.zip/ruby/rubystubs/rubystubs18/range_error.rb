# frozen_string_literal: true

class RangeError < StandardError
end
