# frozen_string_literal: true

class ArgumentError < StandardError
end
