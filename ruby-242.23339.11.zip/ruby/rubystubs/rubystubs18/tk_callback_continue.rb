# frozen_string_literal: true

class TkCallbackContinue < StandardError
end
