# frozen_string_literal: true

class RuntimeError < StandardError
end
