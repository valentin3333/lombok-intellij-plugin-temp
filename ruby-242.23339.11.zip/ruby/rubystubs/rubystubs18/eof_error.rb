# frozen_string_literal: true

class EOFError < IOError
end
