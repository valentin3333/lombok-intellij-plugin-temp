# frozen_string_literal: true

class NotImplementedError < ScriptError
end
