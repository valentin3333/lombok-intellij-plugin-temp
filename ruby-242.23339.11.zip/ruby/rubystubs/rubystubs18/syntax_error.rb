# frozen_string_literal: true

class SyntaxError < ScriptError
end
