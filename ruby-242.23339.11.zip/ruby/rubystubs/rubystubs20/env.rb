# frozen_string_literal: true

# ENV is a hash-like accessor for environment variables.
class ENV
  # Retrieves the +value+ for environment variable +name+ as a String.  Returns
  # +nil+ if the named variable does not exist.
  def self.[](name) end

  # Sets the environment variable +name+ to +value+.  If the value given is
  # +nil+ the environment variable is deleted.
  def self.[]=(name, value) end

  # Returns an Array of the name and value of the environment variable with
  # +name+ or +nil+ if the name cannot be found.
  def self.assoc(name) end

  # Removes every environment variable.
  def self.clear; end

  # Deletes the environment variable with +name+ and returns the value of the
  # variable.  If a block is given it will be called when the named environment
  # does not exist.
  def self.delete(name) end

  # Deletes every environment variable for which the block evaluates to +true+.
  #
  # If no block is given an enumerator is returned instead.
  def self.delete_if; end

  # Yields each environment variable +name+ and +value+.
  #
  # If no block is given an Enumerator is returned.
  def self.each(*several_variants) end

  # Yields each environment variable name.
  #
  # An Enumerator is returned if no block is given.
  def self.each_key; end

  # Yields each environment variable +name+ and +value+.
  #
  # If no block is given an Enumerator is returned.
  def self.each_pair; end

  # Yields each environment variable +value+.
  #
  # An Enumerator is returned if no block was given.
  def self.each_value; end

  # Returns true when there are no environment variables
  def self.empty?; end

  # Retrieves the environment variable +name+.
  #
  # If the given name does not exist and neither +default+ nor a block a
  # provided an IndexError is raised.  If a block is given it is called with
  # the missing name to provide a value.  If a default value is given it will
  # be returned when no block is given.
  def self.fetch(*several_variants) end

  # Returns +true+ if there is an environment variable with the given +name+.
  def self.has_key?(name) end

  # Returns +true+ if there is an environment variable with the given +value+.
  def self.has_value?(value) end

  # Returns +true+ if there is an environment variable with the given +name+.
  def self.include?(name) end

  # Deprecated method that is equivalent to ENV.key
  def self.index(value) end

  # Returns the contents of the environment as a String.
  def self.inspect; end

  # Returns a new hash created by using environment variable names as values
  # and values as names.
  def self.invert; end

  # Deletes every environment variable where the block evaluates to +false+.
  #
  # Returns an enumerator if no block was given.
  def self.keep_if; end

  # Returns the name of the environment variable with +value+.  If the value is
  # not found +nil+ is returned.
  def self.key(value) end

  # Returns +true+ if there is an environment variable with the given +name+.
  def self.key?(name) end

  # Returns every environment variable name in an Array
  def self.keys; end

  # Returns the number of environment variables.
  def self.length; end

  # Returns +true+ if there is an environment variable with the given +name+.
  def self.member?(name) end

  # Returns an Array of the name and value of the environment variable with
  # +value+ or +nil+ if the value cannot be found.
  def self.rassoc(value) end

  # Re-hashing the environment variables does nothing.  It is provided for
  # compatibility with Hash.
  def self.rehash; end

  # Same as ENV#delete_if, but works on (and returns) a copy of the
  # environment.
  def self.reject; end

  # Equivalent to ENV#delete_if but returns +nil+ if no changes were made.
  #
  # Returns an Enumerator if no block was given.
  def self.reject!; end

  # Replaces the contents of the environment variables with the contents of
  # +hash+.
  def self.replace(hash) end

  # Returns a copy of the environment for entries where the block returns true.
  #
  # Returns an Enumerator if no block was given.
  def self.select; end

  # Equivalent to ENV#keep_if but returns +nil+ if no changes were made.
  def self.select!; end

  # Removes an environment variable name-value pair from ENV and returns it as
  # an Array.  Returns +nil+ if when the environment is empty.
  def self.shift; end

  # Returns the number of environment variables.
  def self.size; end

  # Sets the environment variable +name+ to +value+.  If the value given is
  # +nil+ the environment variable is deleted.
  def self.store(name, value) end

  # Converts the environment variables into an array of names and value arrays.
  #
  #   ENV.to_a # => [["TERM", "xterm-color"], ["SHELL", "/bin/bash"], ...]
  def self.to_a; end

  # Creates a hash with a copy of the environment variables.
  def self.to_h(*several_variants) end

  # Creates a hash with a copy of the environment variables.
  def self.to_hash; end

  # Returns "ENV"
  def self.to_s; end

  # Adds the contents of +hash+ to the environment variables.  If no block is
  # specified entries with duplicate keys are overwritten, otherwise the value
  # of each duplicate name is determined by calling the block with the key, its
  # value from the environment and its value from the hash.
  def self.update(hash) end

  # Returns +true+ if there is an environment variable with the given +value+.
  def self.value?(value) end

  # Returns every environment variable value as an Array
  def self.values; end

  # Returns an array containing the environment variable values associated with
  # the given names.  See also ENV.select.
  def self.values_at(name, *args) end
end
