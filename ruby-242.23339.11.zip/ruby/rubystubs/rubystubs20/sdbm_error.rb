# frozen_string_literal: true

# Exception class used to return errors from the sdbm library.
class SDBMError < StandardError
end
