# frozen_string_literal: true

# This is a recommended base class for C extensions using Data_Make_Struct
# or Data_Wrap_Struct, see README.EXT for details.
class Data
end
